import confetti from 'https://cdn.skypack.dev/canvas-confetti';

// Firebase initialization
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, updateDoc } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyDLMoiPCc8Q-CUWH07tF0WTbTYjUqLcrKw",
    authDomain: "clock-a06be.firebaseapp.com",
    projectId: "clock-a06be",
    storageBucket: "clock-a06be.appspot.com",
    messagingSenderId: "422956480062",
    appId: "1:422956480062:web:99fbbb269d5e52206a036f",
    measurementId: "G-M0W6WGJW1Y"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Wrap all DOM-dependent code in a DOMContentLoaded event listener
document.addEventListener('DOMContentLoaded', function() {
    const startBtn = document.getElementById('startBtn');
    const resetBtn = document.getElementById('resetBtn');
    const currentEarningsSpan = document.getElementById('currentEarnings');
    const totalEarningsSpan = document.getElementById('totalEarnings');
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    const closeModalButtons = document.querySelectorAll('.closeModal');
    const submitLoginBtn = document.getElementById('submitLoginBtn');
    const submitRegisterBtn = document.getElementById('submitRegisterBtn');
    const googleSignInBtn = document.getElementById('googleSignInBtn');

    let intervalId;
    let totalEarnings = 0;
    let isLoggedIn = false;
    let userId = null;
    let startTime;
    let earningsPerSecond;

    function formatCurrency(amount, currency) {
        return currency + parseFloat(amount).toFixed(2);
    }

    async function startCounter() {
        try {
            const monthlyPay = parseFloat(document.getElementById('monthlyPay').value);
            const weeklyHours = parseFloat(document.getElementById('weeklyHours').value);
            const includeNonWorkingHours = document.getElementById('includeNonWorkingHours').checked;
            const currency = document.getElementById('currency').value;

            if (isNaN(monthlyPay) || isNaN(weeklyHours)) {
                alert('Please enter valid numbers for monthly pay and weekly hours.');
                return;
            }

            const hoursPerMonth = includeNonWorkingHours ? 730 : weeklyHours * 4;
            earningsPerSecond = monthlyPay / (hoursPerMonth * 3600);

            startTime = new Date().getTime();

            if (isLoggedIn && userId) {
                const userRef = doc(db, "users", userId);
                await setDoc(userRef, {
                    startTime: startTime,
                    earningsPerSecond: earningsPerSecond,
                    currency: currency,
                    totalEarnings: totalEarnings,
                    monthlyPay: monthlyPay,
                    weeklyHours: weeklyHours,
                    includeNonWorkingHours: includeNonWorkingHours
                }, { merge: true });
            }

            startBtn.textContent = 'Stop Hustling';
            startBtn.style.background = 'linear-gradient(to right, #f44336, #d32f2f)';

            updateEarnings(); // Make sure this line is present

        } catch (error) {
            console.error('Error in startCounter:', error);
            alert('An error occurred while starting the counter. Please check the console for more details.');
        }
    }

    async function stopCounter() {
        cancelAnimationFrame(intervalId);
        intervalId = null;
        startBtn.textContent = 'Start Hustling';
        startBtn.style.background = 'linear-gradient(to right, #ffd54f, #ff4081, #e91e63)';

        const finalEarnings = parseFloat(currentEarningsSpan.textContent.replace(/[^0-9.-]+/g,""));
        totalEarnings += finalEarnings;
        
        if (isLoggedIn && userId) {
            const userRef = doc(db, "users", userId);
            await updateDoc(userRef, {
                startTime: null,
                earningsPerSecond: null,
                totalEarnings: totalEarnings
            });
        }

        updateDisplay();
    }

    async function updateEarnings() {
        if (isLoggedIn && userId) {
            const userRef = doc(db, "users", userId);
            const docSnap = await getDoc(userRef);
            if (docSnap.exists()) {
                const data = docSnap.data();
                if (data.startTime && data.earningsPerSecond) {
                    const currentTime = new Date().getTime();
                    const elapsedSeconds = (currentTime - data.startTime) / 1000;
                    const currentEarnings = data.earningsPerSecond * elapsedSeconds;

                    const previousEarnings = parseFloat(currentEarningsSpan.textContent.replace(/[^0-9.-]+/g,""));
                    currentEarningsSpan.textContent = formatCurrency(currentEarnings, data.currency);

                    // Trigger confetti every $1 earned
                    if (Math.floor(currentEarnings) > Math.floor(previousEarnings)) {
                        console.log('Triggering confetti'); // Add this line for debugging
                        confetti({
                            particleCount: 100,
                            spread: 70,
                            origin: { y: 0.6 }
                        });
                    }

                    intervalId = requestAnimationFrame(updateEarnings);
                }
            }
        }
    }

    if (startBtn) {
        startBtn.addEventListener('click', function() {
            console.log('Start button clicked');
            if (intervalId) {
                stopCounter();
            } else {
                startCounter();
            }
        });
    }

    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to reset your earnings? This action cannot be undone.')) {
                totalEarnings = 0;
                const currency = document.getElementById('currency').value;
                currentEarningsSpan.textContent = formatCurrency(0, currency);
                totalEarningsSpan.textContent = formatCurrency(0, currency);

                // Reset the input fields
                document.getElementById('monthlyPay').value = '';
                document.getElementById('weeklyHours').value = '';
                document.getElementById('includeNonWorkingHours').checked = false;

                if (isLoggedIn) {
                    saveProgress();
                }

                // Stop the counter if it's running
                if (intervalId) {
                    stopCounter();
                }
            }
        });
    }

    function showModal(modal) {
        modal.style.display = 'block';
    }

    function closeModal(modal) {
        if (modal) {
            modal.style.display = 'none';
        } else {
            console.error('Modal element is null');
        }
    }

    if (loginBtn) {
        loginBtn.addEventListener('click', () => showModal(loginModal));
    }

    if (registerBtn) {
        registerBtn.addEventListener('click', () => showModal(registerModal));
    }

    closeModalButtons.forEach(button => {
        button.addEventListener('click', () => {
            closeModal(button.closest('.modal'));
        });
    });

    async function loadSavedProgress() {
        if (isLoggedIn && userId) {
            const userRef = doc(db, "users", userId);
            const docSnap = await getDoc(userRef);
            if (docSnap.exists()) {
                const data = docSnap.data();
                totalEarnings = data.totalEarnings || 0;
                document.getElementById('monthlyPay').value = data.monthlyPay || '';
                document.getElementById('weeklyHours').value = data.weeklyHours || '';
                document.getElementById('includeNonWorkingHours').checked = data.includeNonWorkingHours || false;
                document.getElementById('currency').value = data.currency || '$';
                
                // Check if the counter was running
                if (data.startTime && data.earningsPerSecond) {
                    startBtn.textContent = 'Stop Hustling';
                    startBtn.style.background = 'linear-gradient(to right, #f44336, #d32f2f)';
                    
                    // Calculate current earnings based on elapsed time
                    const currentTime = new Date().getTime();
                    const elapsedSeconds = (currentTime - data.startTime) / 1000;
                    const currentEarnings = data.earningsPerSecond * elapsedSeconds;
                    
                    // Update the earnings display
                    currentEarningsSpan.textContent = formatCurrency(currentEarnings, data.currency);
                    totalEarningsSpan.textContent = formatCurrency(totalEarnings + currentEarnings, data.currency);
                    
                    // Start updating earnings
                    updateEarnings();
                } else {
                    updateDisplay();
                }
            }
        }
    }

    function logout() {
        isLoggedIn = false;
        userId = null;
        document.getElementById('loginStatus').textContent = 'Not logged in';
        totalEarnings = 0;
        const currency = document.getElementById('currency').value;
        totalEarningsSpan.textContent = formatCurrency(0, currency);
        currentEarningsSpan.textContent = formatCurrency(0, currency);
    }

    // Ensure to save progress on page unload
    window.addEventListener('beforeunload', function() {
        if (isLoggedIn) {
            saveProgress(); // Save progress when the user leaves the page
        }
    });

    // Add event listener for currency change
    const currencySelect = document.getElementById('currency');
    if (currencySelect) {
        currencySelect.addEventListener('change', function() {
            const currency = this.value;
            currentEarningsSpan.textContent = formatCurrency(parseFloat(currentEarningsSpan.textContent.replace(/[^0-9.-]+/g,"")), currency);
            totalEarningsSpan.textContent = formatCurrency(totalEarnings, currency);
        });
    }

    function signInWithGoogle() {
        console.log('Google Sign-In button clicked'); // Debugging log
        const provider = new GoogleAuthProvider();
        signInWithPopup(auth, provider)
            .then((result) => {
                const user = result.user;
                console.log("User signed in:", user);
                // Update UI without showing the email
                document.getElementById('loginStatus').textContent = `Logged in`; // Change this line
                isLoggedIn = true;
                userId = user.uid;
                loadSavedProgress();
                closeModal(loginModal);
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                console.error("Error signing in with Google:", errorCode, errorMessage);
                alert("Error signing in with Google: " + errorMessage);
            });
    }

    if (googleSignInBtn) {
        googleSignInBtn.addEventListener('click', signInWithGoogle);
    } else {
        console.error('Google Sign-In button not found in the DOM');
    }

    function updateDisplay() {
        const currency = document.getElementById('currency').value;
        currentEarningsSpan.textContent = formatCurrency(0, currency);
        totalEarningsSpan.textContent = formatCurrency(totalEarnings, currency);
    }

    // Call updateDisplay initially to set up the initial values
    updateDisplay();

    if (loginModal) {
        console.log('Login modal found');
    } else {
        console.error('Login modal not found in the DOM');
    }

    // Remove the check for localStorage
    loadSavedProgress();
});